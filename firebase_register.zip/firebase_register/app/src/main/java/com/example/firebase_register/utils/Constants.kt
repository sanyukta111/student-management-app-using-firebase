package com.example.firebase_register.utils

object Constants {

    const val SEND_ID = "SEND_ID"
    const val RECEIVE_ID = "RECEIVE_ID"

    const val OPEN_GOOGLE = "Opening Google..."
    const val OPEN_SEARCH = "Searching..."
    const val OPEN_EXAM_FORM = "Opening Sppu..."
    const val OPEN_RESULT = "Opening sppu result..."
    const val OPEN_ASSIGNMENT = "opening assignment page...."
}