package com.example.firebase_register;

import android.content.DialogInterface;

public interface ToDoOnDialogCloseListner {

    void onDialogClose(DialogInterface dialogInterface);
}
